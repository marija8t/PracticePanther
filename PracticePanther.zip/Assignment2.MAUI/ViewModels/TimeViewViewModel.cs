﻿using System;
using Assignment1.Library.Models;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Assignment1.Library.Services;
using System.Collections.ObjectModel;

namespace Assignment2.MAUI.ViewModels
{
	public class TimeViewViewModel : INotifyPropertyChanged
	{
        private Time selectedTime;
        public Time SelectedTime
        {
            get { return selectedTime; }
            set
            {
                selectedTime = value;
                NotifyPropertyChanged();
            }
        }


        private ObservableCollection<TimeViewModel> times;
        public ObservableCollection<TimeViewModel> Times
        {
            get { return times; }
            set
            {
                times = value;
                NotifyPropertyChanged();
            }
        }


        public TimeViewViewModel()
        {
            SelectedTime = new Time();
            RefreshTimeList();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged([CallerMemberName] String propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public void RefreshTimeList()
        {
            Times = new ObservableCollection<TimeViewModel>(
                TimeService.Current.Times.ConvertAll(t => new TimeViewModel(t)));
        }


    }
}

