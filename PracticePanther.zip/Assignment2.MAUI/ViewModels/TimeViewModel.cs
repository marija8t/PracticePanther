﻿using System;
using System.Windows.Input;
using Assignment1.Library.Models;
using Assignment1.Library.Services;

namespace Assignment2.MAUI.ViewModels
{
	public class TimeViewModel
	{
        public Time Model { get; set; }

        public string Display => Model.ToString() ?? string.Empty;

        public TimeViewModel(Time time)
        {
            Model = time;
            SetupCommands();
            
        }

        private void SetupCommands()
        {
            DeleteCommand = new Command(
                (t) => ExecuteDelete((t as TimeViewModel).Model));
            //EditCommand = new Command(
            //        (c) => ExecuteEdit((c as EmployeeViewModel).Model.Id));
        }
        
//-------------------------------------------------DELETE---------------------------------------------------
        public ICommand DeleteCommand { get; private set; }

        public void ExecuteDelete(Time time)
        {
            TimeService.Current.Delete(time);
        }
    }
}

