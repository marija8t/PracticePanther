﻿using System;
using Assignment1.Library.Services;
using Assignment1.Models;
using System.Collections.ObjectModel;

namespace Assignment2.MAUI.ViewModels
{
	public class ProjectViewViewModel
	{
        public Client Client { get; set; }
        public ObservableCollection<Project> Projects
        {
            get
            {
                if (Client == null || Client.Id == 0)
                {
                    return new ObservableCollection<Project>
                    (ProjectService.Current.Projects);
                }
                return new ObservableCollection<Project>
                    (ProjectService.Current.Projects
                    .Where(p => p.ClientId == Client.Id));
            }
        }
        public ProjectViewViewModel(int clientId)
        {
            if (clientId > 0)
            {
                Client = ClientService.Current.Get(clientId);
            }
            else
            {
                Client = new Client();
            }

        }
    }
}

