﻿using Assignment1.Models;
using Assignment2.MAUI.ViewModels;

namespace Assignment2.MAUI.Views;

[QueryProperty(nameof(ClientId), "clientId")]
public partial class ProjectDetailView : ContentPage
{
    public int ClientId { get; set; }
    public ProjectDetailView()
	{
		InitializeComponent();
	}

    private void OnArrived(object sender, NavigatedToEventArgs e)
    {
        BindingContext = new ProjectViewModel(ClientId);
    }

    //private void OkClicked(object sender, EventArgs e)
    //{
    //    //Shell.Current.GoToAsync($"//ClientDetail?clientId={SelectedClient?.Id ?? 0}");
    //    (BindingContext as ClientViewModel).AddOrUpdate();
    //    Shell.Current.GoToAsync("//Clients");
    //}

    void CancelClicked(System.Object sender, System.EventArgs e)
    {
        Shell.Current.GoToAsync("//ClientDetail");
    }
}
