﻿using Assignment2.MAUI.ViewModels;

namespace Assignment2.MAUI.Views;

public partial class TimeView : ContentPage
{
	public TimeView()
	{
		InitializeComponent();
        BindingContext = new TimeViewViewModel();
    }

    void GoBackClicked(System.Object sender, System.EventArgs e)
    {
        Shell.Current.GoToAsync("//MainPage");
    }

    private void OnArrived(object sender, NavigatedToEventArgs e)
    {
        (BindingContext as TimeViewViewModel).RefreshTimeList();
    }

    void DeleteClicked(System.Object sender, System.EventArgs e)
    {
        (BindingContext as TimeViewViewModel).RefreshTimeList();
        
    }
}
