﻿using System;
using Assignment1.Library.Models;
using Assignment1.Models;

namespace Assignment1.Library.Services
{
	public class TimeService
	{
        public List<Time> Times
        {
            get
            {
                return times;
            }
        }

        private List<Time> times;

        private static TimeService? instance;

        private static object _lock = new object();

        public static TimeService Current
        {
            get
            {
                lock (_lock)
                {
                    if (instance == null)
                    {
                        instance = new TimeService();
                    }
                }
                return instance;
            }

        }

        private TimeService()
        {
            times = new List<Time>
            {

                new Time{ Hours = 1, Date = DateTime.Now},
                new Time{ Hours = 2, Date = new DateTime(2023, 6, 30, 13, 30, 0)}
            };
     
        }
//------------------------------------EDIT----------------------------------------------------
        public void EditTime(Time time)
        {
            
        }
//------------------------------------ADD----------------------------------------------------
        public void AddTime(Time time)
        {

        }
 //------------------------------------DELETE----------------------------------------------------
        public void Delete(Time time)
        {
            times?.Remove(time);
        }


    }
}

